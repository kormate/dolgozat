﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Doga03_07
{
    public class reading
    {
        public int sorszam;
        public string neve;
        public int megjelenes;
        public string mufaj;


        public reading(int sorszam, string neve, int megjelenes, string mufaj)
        { 
            this.sorszam = sorszam;
            this.neve = neve;
            this.megjelenes = megjelenes;
            this.mufaj = mufaj;
        }

        public override string ToString()
        {
            return base.ToString();
        }
    }
}
