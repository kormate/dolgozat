﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Doga03_07
{
    internal class Program
    {

        public struct jatekok
        {
            public int sorszam;
            public string neve;
            public int megjelenes;
            public string mufaj;
        }
        static void Main(string[] args)
        {
            List<jatekok> jatek = new List<jatekok>();
            FileStream fs = new FileStream("bestgames.txt", FileMode.Open);
            StreamReader sr = new StreamReader(fs, Encoding.UTF8);

            string sor = "";
            while (!sr.EndOfStream) 
            {
                sor = sr.ReadLine();
                string[] dr = sor.Split(',');
                jatekok j = new jatekok();
                j.sorszam = Convert.ToInt32(dr[0]);
                j.neve = dr[1];
                j.megjelenes = Convert.ToInt32(dr[2]);
                j.mufaj = dr[3];
                jatek.Add(j);
            }
            sr.Close();
            fs.Close();

            

            int osszesJatek = 0;
            for (int i = 0; i < jatek.Count; i++)
            {
                osszesJatek += jatek[i].sorszam;
            }
            Console.WriteLine($"Összesen {osszesJatek} játék szerepel a listában!");

            



           /* var fajl = new StreamReader("bestgames.txt").ReadToEnd();
            var sorok = fajl.Split(new char[] { '\n' });
            var count = sorok.Count();

            Console.WriteLine($"Összesen {count} játék szerepel a listában!");*/




            

            

            Console.ReadKey();
        }
    }
}
