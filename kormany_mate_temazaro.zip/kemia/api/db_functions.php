<?php 
    function adatLeker($sql){
        $array = false;
        $kapcsolat = connect();
        $e = $kapcsolat->query($sql);
        if($e && $e->num_rows > 0){
            $n = 0;
            while($sor = $e->fetch_assoc()){
                $array[$n] = $sor;
                $n++;
            }
        }
        $kapcsolat -> close();
        return $array;
    }

    function adatLekerErtek($sql){
        $array = false;
        $kapcsolat = connect();
        $e = $kapcsolat->query($sql);
        if($e && $e->num_rows > 0){
            $sor = $e->fetch_assoc();
            $value = $sor[0];
    }
    $kapcsolat -> close();
    return $array;
}

    function LekerAll(){
        $sql = "SELECT * FROM elemek";
        return adatLeker($sql);
    }
?>