<?php 
    include_once("db_connect.php");
    include_once("db_functions.php");

    if (isset($_GET["elemek"]) && $_GET["elemek"] == "mind") $adat = LekerAll() ;
    if (isset($adat)){
        $kod = 200;
        if (!$adat){
            $kod = 204;
            $adat = array(
                "uzenet"=> "nincs találat",
            );
        }
    }
    else{
    $kod = 404;
    $adat = array(
        "minta1"=> "?elemek=mind",
        "minta2"=> "?elemek=Hélium",
        "minta3"=> "?halmaz=gáz",
    );
    }

    http_response_code($kod);
    header("Content-Type: application/json; charset=utf-8");
    $json = json_encode($adat);

    print $json;
?>