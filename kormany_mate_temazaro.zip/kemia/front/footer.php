<footer>
	<div>Források: <a target="_blank" href="https://hu.wikipedia.org/wiki/K%C3%A9miai_elemek_peri%C3%B3dusos_rendszere">Periódusos rendszer</a> | <a target="_blank" href="https://hu.wikipedia.org/wiki/K%C3%A9miai_elemek_list%C3%A1ja">Elemek</a> | <a target="_blank" href="https://hu.wikipedia.org/wiki/K%C3%A9miai_elemek_felfedez%C3%A9si_d%C3%A1tum_szerinti_list%C3%A1ja">Felfedezők</a>
	<br><br>
	<div class="author">by Kormány Máté || 2024.03.22</div>
	<div class="link">
	<a id="up" href="#pagetop">&#8657;</a>
	</div>
</footer>

</body>
</html>