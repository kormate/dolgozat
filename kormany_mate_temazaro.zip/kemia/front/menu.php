<?php
$page="pages/start.php";

if (isset($_GET['p'])){
	switch ($_GET['p']) {
		case '1': {
			
			break;
		}
		case '2': {
			$page = 'pages/elemek.php';
			break;
		}
	}
}

?>