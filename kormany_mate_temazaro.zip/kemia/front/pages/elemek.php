<?php 
    $mind = getApi($apiUrl."?elemek=mind");
    if (!$mind) $mind=[];
?>

<div class='page'>
    <?php include("tabla.php"); ?>
</div>