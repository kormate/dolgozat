<h1>Kémiai elemek periódusos rendszere</h1>
<p>

A kémiai elemek periódusos rendszere (más néven: Mengyelejev-táblázat) a kémiai elemek egy táblázatos megjelenítése, amelyben az elemek rendszámuk (vagyis protonszámuk), elektronszerkezetük, és ismétlődő kémiai tulajdonságaik alapján vannak elrendezve. Ez az elrendezés jól szemlélteti az elemek periodikusan változó tulajdonságait, mivel a kémiailag hasonlóan viselkedő elemek így gyakran egy oszlopba kerülnek. A táblázat négy téglalap alakú mezőt (s-, p-, d-, f-mező) is tartalmaz amelyeken belül egyes kémiai tulajdonságok hasonlóságokat mutatnak. Általánosságban elmondható, hogy a sorok (periódusok) bal oldalán fémek, a jobb oldalán pedig nemfémek helyezkednek el.

</p>
<p><img src="./front/img/period.jpg" style="margin-left:50px;"></p>
<p>
A periódusos rendszer sorait periódusoknak nevezzük, az oszlopokat pedig csoportoknak. Néhány csoportnak a sorszáma mellett saját neve is van, például a 18-as csoportot nemesgázokként, a 17-es csoportot halogénekként is ismerik, de egyes csoportoknál a csoport első tagjából képzett nevet is használják, például széncsoport, nitrogéncsoport. A periódusos rendszer használható az elemek tulajdonságai közti kapcsolatok levezetésére, de akár még fel nem fedezett elemek tulajdonságait is meg lehet jósolni a segítségével. A kémia oktatásában ma általánosan elterjedt a periódusos rendszer használata, a kémiai sajátosságok különböző formáinak az osztályozásához, rendszerezéséhez és összehasonlításához hasznos segédeszköz. A táblázatot széleskörűen használják a kémiában, fizikában, biológiában és az iparban.
</p>
<p>
Dmitrij Ivanovics Mengyelejev orosz kémikus tette közzé az első szélesebb körben elismert periódusos rendszert 1869-ben. Felismerte, hogy az akkor ismert elemek tulajdonságai a rendszámuk alapján periodikusan váltakoznak. Mengyelejev emellett megjósolta a táblázat akkor még üres helyeire kerülő elemek néhány tulajdonságát. Előrejelzései a kérdéses elemek felfedezése után többnyire beigazolódtak. Mengyelejev periódusos rendszerét azóta új elemek felfedezésével és a kémiai viselkedést leíró újabb modellekkel bővítették és finomították.
</p>
<p>
Az összes elemet az 1-es rendszámtól kezdve (hidrogén) a 118-asig (oganeszon) bezáróan felfedezték vagy mesterségesen előállították már, és a periódusos rendszer első hét periódusa teljessé vált a nihónium, moszkóvium, tenesszium és oganeszon felfedezésével, melyet az IUPAC 2015. december 30-án igazolt, hivatalos nevüket pedig 2016. november 28-án kapták meg. Az első 94 elem mindegyike megtalálható a természetben, bár néhányuk csak nyomnyi mennyiségben, és hamarabb állították elő őket laboratóriumban, minthogy a természetben felfedezték volna őket. A 95–118-as rendszámú elemeket csak laboratóriumokban vagy nukleáris reaktorokban állították elő. Ennél nagyobb rendszámú elemek szintézisére folyamatosan történnek próbálkozások. Számos természetben előforduló elem szintetikus radioizotópját is előállították már laboratóriumokban.

</p>