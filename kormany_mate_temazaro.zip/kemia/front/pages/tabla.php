<p class="center">
	</p>
	<table border="1px solid black" class="center" style="margin-left: 255px;">
		<tr><th>Rendszám</th><th>Név</th><th>Vegyjel</th><th>Felfedezve</th><th>Felfedező</th></tr>
		<?php
			foreach ($mind as $rekord)
				echo "<tr>
					<td>$rekord[rendszam]</td>
					<td>$rekord[nev]</td>
					<td>$rekord[vegyjel]</td>
					<td>$rekord[ev]</td>
					<td>$rekord[felfedezo]</td>
				</tr>";
		?>
	</table>