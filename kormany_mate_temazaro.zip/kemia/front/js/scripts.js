// When the user scrolls down
window.onscroll = function() {scrollFunction("up")};

function scrollFunction(myBtn) {
	var mybutton = document.getElementById(myBtn);
  if (document.body.scrollTop > 1000 || document.documentElement.scrollTop > 1000) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}