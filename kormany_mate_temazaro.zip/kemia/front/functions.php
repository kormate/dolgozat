<?php
function getApi($url) {
	$json=file_get_contents($url);
	if (http_response_code()==404) return false;
	else return json_decode($json,true);
}

function szures($mit){
    $lista = array();
    foreach ($mit as $rekord) {
        if ($rekord["rendszam"] == intval($_GET["rendszam"]))
        array_push($lista,$rekord);
    }
    return $lista;
}

?>