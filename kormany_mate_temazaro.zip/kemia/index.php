<?php 

		
		$myUrl="localhost/kemia/";
		$apiUrl=$myUrl."api/";

	
		include_once("front/functions.php");
		
		include_once("front/load.php");

?>