﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace dogaform03_07
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        struct jatekok
        {
            public int sorszam;
            public string nev;
            public int megjelenes;
            public string mufaj;
        }

        List<jatekok> jatekLista = new List<jatekok>();

        const char tabulator = '\t';

        void fajlbeo()
        {
            FileStream fs = new FileStream("bestgames.txt", FileMode.Open);
            StreamReader sr = new StreamReader(fs);
            while (!sr.EndOfStream)
            {
                string[] sorok = sr.ReadLine().Split(tabulator);
                jatekok jatek = new jatekok();
                jatek.sorszam = Convert.ToInt32(sorok[0]);
                jatek.nev = sorok[1];
                jatek.megjelenes = Convert.ToInt32(sorok[2]);
                jatek.mufaj = sorok[3];
                jatekLista.Add(jatek);
            }
            sr.Close();
            fs.Close();

            
        }

        void tablafeltolt()
        {
            foreach (jatekok jatek in jatekLista)
            {
                dataGridView1.Rows.Add(
                    jatek.sorszam,
                    jatek.nev,
                    jatek.megjelenes,
                    jatek.mufaj
                    );
            }
        }




        private void Form1_Load(object sender, EventArgs e)
        {
            fajlbeo();

            tablafeltolt();

        }

        private void comboBoxGenre_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBoxTitle_KeyDown(object sender, KeyEventArgs e)
        {
           
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {

        }
    }
}
